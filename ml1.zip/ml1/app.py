from flask import Flask, render_template, jsonify, request
import pandas as pd
import json
from datetime import datetime
from sklearn.cluster import KMeans
from sklearn.linear_model import LinearRegression
import numpy as np

app = Flask(__name__)

# Load and preprocess data
def load_data():
    with open('vehicle_time_slot_dataset_2000 (1).json', 'r') as f:
        data = json.load(f)
    df = pd.DataFrame(data)
    
    # Convert timestamps to datetime
    df['Entry_Time'] = pd.to_datetime(df['Entry_Time'])
    df['Exit_Time'] = pd.to_datetime(df['Exit_Time'])
    
    # Extract features
    df['hour'] = df['Entry_Time'].dt.hour
    df['day_of_week'] = df['Entry_Time'].dt.dayofweek
    return df

# Train models
def train_models(df):
    # Clustering model for parking zones
    X_cluster = df[['hour', 'day_of_week']]
    kmeans = KMeans(n_clusters=4, random_state=42)
    df['zone'] = kmeans.fit_predict(X_cluster)
    
    # Regression model for occupancy prediction
    X_reg = df[['hour', 'day_of_week']]
    y_reg = df['Duration_Minutes']
    reg_model = LinearRegression()
    reg_model.fit(X_reg, y_reg)
    
    return kmeans, reg_model, df

# Load data and train models
df = load_data()
kmeans, reg_model, df = train_models(df)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/find_parking')
def find_parking():
    return render_template('find_parking.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/api/predict', methods=['POST'])
def predict():
    data = request.json
    hour = int(data['hour'])
    day_of_week = int(data['day_of_week'])
    
    # Predict occupancy
    prediction = reg_model.predict([[hour, day_of_week]])
    
    # Get zone recommendation
    zone = kmeans.predict([[hour, day_of_week]])[0]
    
    return jsonify({
        'predicted_occupancy': float(prediction[0]),
        'recommended_zone': int(zone)
    })

@app.route('/api/stats')
def get_stats():
    # Calculate basic statistics
    hourly_stats = df.groupby('hour').agg({
        'Duration_Minutes': 'mean',
        'Slot_ID': 'count'
    }).reset_index()
    
    return jsonify({
        'hourly_stats': hourly_stats.to_dict('records')
    })

if __name__ == '__main__':
    app.run(debug=True) 